def classFactory(iface):
    from .DividirLotes import DividirLotes
    return DividirLotes(iface)